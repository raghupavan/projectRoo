package com.example.raj.rookart;


public interface OnGetdata {
    void OnGetExecuted(String result);
}
